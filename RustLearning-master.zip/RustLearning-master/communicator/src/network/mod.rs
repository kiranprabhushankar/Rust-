fn connect() {}

// mod server; // This cannot be done create a new dir named network and move network.rs to that forlde rand rename as mod.rs
