fn main() {
let s1 = String::from("hello");
println!("{}, world!", s1);
let s2 = s1;

println!("{}, world!", s2);
}
